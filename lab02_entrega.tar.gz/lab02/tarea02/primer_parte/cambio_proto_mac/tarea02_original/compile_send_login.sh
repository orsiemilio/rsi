sudo make TARGET=sky $1.upload &&  make TARGET=sky login
